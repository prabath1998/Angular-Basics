export interface Feature {
  title: string;
  imagePath: string;
  price: number;
}
